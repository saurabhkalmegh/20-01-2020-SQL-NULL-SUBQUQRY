﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace class1
 
    {
    class student
    {
        int studentID;
        string studentname;

        public int SID
        {
            get
            {
                return studentID;
            }
            set 
            {
                studentID = value;
            }
        }

        public string sname
        {
            get
            {
                return studentName;
            }
            set
            {
                studentName= value;
            }
        }
        public void printDetails()
        {
            Console.WriteLine("student ID :{0}", SID);
            Console.WriteLine("student Name : " + SName);

        }

    }
    class program
    {
        static void main(string[] args)
        {

            student student = new class1.student();
            Console.Write("Enter student ID:");
            student.SID = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter student name");
            student = Convert.ReadLine();
            student.printDetails();
            Console.ReadKey();
        }  
    }



}