﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class bill
    {
        int x, y, z;
       public  bill()
        {
            int a;
            Console.WriteLine("Please Enter Your Unites");
           a= Convert.ToInt32(Console.ReadLine());
            func1(a);


        }
        public  bill(int y,int z,int i)
        {
            this.x = y;
            this.y = z;
            this.z = i;
            Console.WriteLine((y + z + i).ToString());
        }

    
        public void func1(int units)
        {
            if (units >= 0 && units <= 500)
            {
                double d, c;
                d = units * 0.75;
                c = d + (d * 0.20);
                Console.WriteLine("your domestic units result is" + d);
                Console.WriteLine("your consumer units result is" + c);
            }
            else if (units >= 501 && units <= 1000)
            {
                double d, c;
                d = units * 2.35;
                c = d + (d * 0.20);
                Console.WriteLine("your domestic units result is" + d);
                Console.WriteLine("your consumer units result is" + c);
            }
            else if (units >= 1001 && units <= 1500)
            {
                double d, c;
                d = units * 3.05;
                c = d + (d * 0.20);
                Console.WriteLine("your domestic units result is" + d);
                Console.WriteLine("your consumer units result is" + c);
            }
            else if (units >= 1501 && units <= 2000)
            {
                double d, c;
                d = units * 4;
                c = d + (d * 0.20);
                Console.WriteLine("your domestic units result is" + d);
                Console.WriteLine("your consumer units result is" + c);
            }
            else if (units >= 2001)
            {
                double d, c;
                d = units * 5.15;
                c = d + (d * 0.20);
                Console.WriteLine("your domestic units result is" + d);
                Console.WriteLine("your consumer units result is" + c);
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            bill a = new bill (1, 2, 3);
            bill b = new bill();
        

            Console.ReadKey();
        }

    }
}
